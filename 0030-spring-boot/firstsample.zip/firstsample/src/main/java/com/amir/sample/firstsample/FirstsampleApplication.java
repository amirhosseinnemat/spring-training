package com.amir.sample.firstsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstsampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstsampleApplication.class, args);
	}

}
